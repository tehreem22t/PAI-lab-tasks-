from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot():
    msg = request.form["msg"].lower()

    if "admission" in msg:
        reply = "Admissions are open now for Fall 2026."
    
    elif "requirement" in msg or "criteria" in msg:
        reply = "You need Intermediate with at least 50% marks."

    elif "deadline" in msg or "last date" in msg:
        reply = "Last date to apply is 30 August 2026."

    elif "program" in msg or "degree" in msg:
        reply = "We offer BSCS, BBA, BS IT, BS English."

    elif "fee" in msg:
        reply = "Semester fee starts from Rs. 45,000."

    elif "contact" in msg:
        reply = "Call us at 042-1234567."

    elif "hello" in msg or "hi" in msg:
        reply = "Hello! Welcome to University Admission Bot."

    else:
        reply = "Sorry, I didn't understand. Please ask about admissions, fee, programs, deadlines."

    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)