from flask import Flask, render_template, request
from sentence_transformers import SentenceTransformer
import numpy as np
import pickle

app = Flask(__name__)

# Load model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load saved data
with open("data.pkl", "rb") as f:
    questions, answers, q_embeddings = pickle.load(f)

# Cosine similarity function
def cosine_similarity(a, b):
    a = np.array(a)
    b = np.array(b)
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

@app.route("/", methods=["GET", "POST"])
def home():
    response = ""

    if request.method == "POST":
        query = request.form["query"]

        # Query embedding
        q_vec = model.encode(query)

        # Find best match
        scores = []

        for emb in q_embeddings:
            score = cosine_similarity(q_vec, emb)
            scores.append(score)

        best_idx = np.argmax(scores)
        response = answers[best_idx]

    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(debug=True)