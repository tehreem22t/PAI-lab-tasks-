from sentence_transformers import SentenceTransformer
import numpy as np
import pickle

# Load MiniLM model
model = SentenceTransformer('all-MiniLM-L6-v2')

questions = []
answers = []

# Load dataset
with open("admission_faq.txt", "r", encoding="utf-8") as f:
    lines = f.readlines()

for i in range(0, len(lines), 3):
    q = lines[i].replace("Q:", "").strip()
    a = lines[i+1].replace("A:", "").strip()
    questions.append(q)
    answers.append(a)

# Convert questions to embeddings
q_embeddings = model.encode(questions)

# Save embeddings + answers
with open("data.pkl", "wb") as f:
    pickle.dump((questions, answers, q_embeddings), f)

print("Index created WITHOUT FAISS successfully!")