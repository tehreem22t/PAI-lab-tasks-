from flask import Flask, render_template, request
from generator import generate_application

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/generate', methods=['POST'])
def generate():

    name = request.form['name']
    app_type = request.form['type']
    topic = request.form['topic']
    language = request.form['language']
    tone = request.form['tone']

    result = generate_application(name, app_type, topic, language, tone)

    return render_template("result.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)