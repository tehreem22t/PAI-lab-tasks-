def generate_application(name, app_type, topic, language, tone):

    if language == "English":

        if app_type == "Leave":
            body = f"I am writing to request leave due to {topic}. Kindly grant me leave."

        else:
            body = f"I would like to file a complaint regarding {topic}. Kindly resolve this issue."

        ending = f"Thank you.\nSincerely,\n{name}"

    else:

        if app_type == "Leave":
            body = f"میں {topic} کی وجہ سے چھٹی کی درخواست کرتا/کرتی ہوں۔ براہ کرم چھٹی دی جائے۔"

        else:
            body = f"میں {topic} کے متعلق شکایت درج کروانا چاہتا/چاہتی ہوں۔ براہ کرم مسئلہ حل کیا جائے۔"

        ending = f"شکریہ\n{name}"

    if tone == "Professional":
        body += " Your cooperation will be appreciated."

    elif tone == "Friendly":
        body += " I hope for your support."

    letter = f"""
To,
The Manager / Principal

Subject: {app_type} Application

Respected Sir/Madam,

{body}

{ending}
"""

    return letter